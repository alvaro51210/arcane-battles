# Arcane Battles — versión corregida + multijugador real

Esta versión conserva la estética original de la interfaz y sustituye el antiguo sistema P2P/local por un servidor autoritativo. El cliente ya no decide el resultado de las partidas online: el servidor valida turnos, cartas, maná, ataques, objetivos y resultados.

## Requisitos

- Node.js 20 o superior.
- npm.
- Para jugar en la misma red o por Internet, el servidor debe estar ejecutándose y ser accesible desde los dos navegadores.

## Ejecutar en tu ordenador

1. Descomprime el proyecto.
2. Abre una terminal dentro de la carpeta `arcane_battles_project`.
3. Ejecuta `npm install`.
4. Ejecuta `npm start`.
5. Abre `http://localhost:3000` en el navegador.
6. Para probar con dos personas en el mismo ordenador, abre una ventana normal y otra de incógnito, registra dos cuentas y conéctalas mediante sala pública, privada o matchmaking.

No abras `public/index.html` directamente con doble clic (`file://`): las cuentas y el WebSocket necesitan el servidor.

## Funciones incluidas

- Registro e inicio de sesión centralizados. Las contraseñas nuevas se guardan con `scrypt` y salt aleatorio. Si existe una cuenta de la versión local, al iniciar sesión puede transferir el nombre, contraseña y mazo al servidor; el ELO empieza en 1000 y las estadísticas locales no se importan. La copia local de esa cuenta se elimina tras la migración.
- Perfiles, mazos y solicitudes de amistad compartidos en el servidor.
- Salas públicas listadas en tiempo real.
- Salas privadas de seis caracteres e invitaciones a amigos conectados.
- Cola de matchmaking clasificatorio que empareja por ELO y amplía gradualmente el margen de búsqueda.
- Ranking global, rangos y cambios de ELO después de partidas clasificatorias.
- Servidor autoritativo para las partidas online; se ocultan la mano y el mazo del oponente.
- Recuperación de conexión durante una ventana de 45 segundos.
- Constructor con búsqueda real en las 500 cartas, filtro de coste corregido, máximo de 30 cartas y límites de copias (2 normales / 1 legendaria).
- Reglas compartidas para IA y online: coste de maná, gritos de batalla, cinco efectos de hechizo, límite de campo, Provocar, Escudo divino, combate, fatiga y victoria/derrota.

## Publicar para jugar por Internet

El proyecto incluye el servidor, pero no incluye un servidor público ya contratado ni una URL pública. Para jugar con amigos desde casas distintas tienes que desplegar esta carpeta en un VPS o plataforma compatible con Node.js y WebSockets.

- Usa HTTPS/WSS (certificado TLS) y configura `NODE_ENV=production`.
- Mantén un disco persistente para `data/arcane-db.json`, porque contiene las cuentas y el progreso.
- Ejecuta una sola instancia del servidor con esta base JSON. Para escalar a varias instancias, reemplaza el almacenamiento JSON y las colas en memoria por una base de datos y un almacén compartido (por ejemplo PostgreSQL + Redis).
- No compartas ni publiques `data/arcane-db.json`.

## Arquitectura

- `public/index.html`: interfaz del juego.
- `public/app.js`: interfaz, navegación, colección, constructor, IA y cliente WebSocket.
- `public/shared/cards.js`: catálogo determinista de 500 cartas, compartido por cliente y servidor.
- `public/shared/game-engine.js`: reglas de juego compartidas.
- `server.js`: autenticación, sesiones, salas, matchmaking, clasificación, persistencia y WebSocket.
- `data/arcane-db.json`: se crea automáticamente al registrar la primera cuenta.

## Comprobaciones

Ejecuta `npm test` para validar las reglas centrales. `node --check server.js` comprueba la sintaxis del servidor. Las pruebas automáticas no sustituyen una prueba real de red entre dos dispositivos ni una revisión de seguridad antes de abrir el servicio al público.

## Limitaciones que conviene conocer

- Las 500 cartas siguen generándose mediante patrones, como en la versión original; no son 500 diseños equilibrados individualmente.
- Este es un servidor funcional de partida y matchmaking para una primera versión, no una infraestructura de esports a gran escala. Para producción pública real conviene añadir monitorización, copias de seguridad, moderación, protección anti-abuso más completa y persistencia SQL/Redis.
- Las salas públicas solo muestran salas en espera que tengan anfitrión conectado. La cola competitiva empareja a usuarios que estén conectados al mismo servidor.
